============================================
  Halo Infinite
  Digital Download - NedGaming Store
============================================

Developer: 343 Industries
Version: 1.0
Platform: PC Windows 10/11 64-bit

INSTRUCTIONS D'INSTALLATION:
1. Executez Setup.exe en tant qu'administrateur
2. Suivez les instructions a l'ecran
3. Choisissez le dossier d'installation
4. Attendez la fin de l'installation
5. Lancez le jeu depuis le raccourci bureau

CONFIGURATION MINIMALE:
- OS: Windows 10 64-bit
- Processeur: Intel Core i5 / AMD Ryzen 5
- RAM: 8 Go
- Carte graphique: GTX 1060 / RX 580
- Espace disque: 50 Go

Achat valide sur NedGaming Store
Paiement Mobile Money - Gabon
